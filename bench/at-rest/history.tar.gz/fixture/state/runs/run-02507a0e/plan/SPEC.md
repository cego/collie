# Fixture plan

Keep the host responsive with a large history.
